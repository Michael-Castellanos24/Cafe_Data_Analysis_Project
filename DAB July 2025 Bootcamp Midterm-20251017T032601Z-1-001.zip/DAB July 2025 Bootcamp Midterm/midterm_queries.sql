/*Midterm: Cafe Sales Queries

This file contains all SQL queries used in the analysis.
Queries are grouped into two categories:
1. Exploratory Queries – Data exploration and quality checks
2. Business Insight Queries – Answering key business questions */


--Exploritory Queries

-- Counting amout of Takeaway orders
SELECT COUNT(*) AS takeaway_transactions
FROM cafe_sales
WHERE location = 'Takeaway';

/* Sample Result:

Takeaway_transactions
----------------------
5000
*/



-- Counting how many coffee orders there were
SELECT COUNT(*) AS "Total Coffee Orders"
FROM cafe_sales
WHERE item = 'Coffee';

/* Sample Result:

coffee_orders
----------------------
1500
*/

-- Counting total number of orders where $10 or more was spent
SELECT COUNT(transaction_id) AS 'Number of orders $10 or more'
FROM cafe_sales
WHERE total_spent_num IS NOT NULL
  AND total_spent_num >= 10;
  
  /* Sample Result:

Number of orders $10 or more
----------------------
3200
*/
  

--Business Queries

--Average Spending by Location
SELECT location,
       COUNT(transaction_id) AS num_transactions,
       SUM(total_spent_num) AS total_revenue,
       ROUND(AVG(total_spent_num), 2) AS avg_transaction_value
FROM cafe_sales
WHERE total_spent_num IS NOT NULL
  AND location != 'UNKNOWN'
GROUP BY location
ORDER BY total_revenue DESC;

/* Sample Result:
   location  | num_transactions | total_revenue | avg_transaction_value
   --------- | ---------------- | ------------- | ---------------------
   In-Store  | 850              | 5400.75       | 6.35
   Takeaway  | 640              | 4100.25       | 6.41
*/


--Ranking best selling items by total revenue
SELECT item,
       SUM(total_spent_num) AS total_revenue,
       COUNT(transaction_id) AS num_sold
FROM cafe_sales
WHERE total_spent_num IS NOT NULL
  AND item != 'UNKNOWN'
GROUP BY item
ORDER BY total_revenue DESC;

/* Sample Result:
   item       | total_revenue | num_sold
   ---------- | ------------- | --------
   Salad      | 15000.00      | 1020
   Sandwich   | 11900.00      | 980
   Smoothie   | 11875.00      | 950
*/

--Seeing which days had the least transactions
SELECT transaction_date,
       COUNT(transaction_id) AS num_transactions
FROM cafe_sales
WHERE transaction_date NOT IN('UNKNOWN')
GROUP BY transaction_date
ORDER BY num_transactions ASC
LIMIT 50;

/* Sample Result:
   transaction_date | num_transactions
   ---------------- | ----------------
   11/24/2023       | 14
   7/20/2023        | 16
   1/1/2023         | 21
*/